<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit(0);
$this->need('header.php');
?>
<?php
$hidden_sidebar =  !empty($this->options->ShowBlock) && in_array('SidebarHiddenInDetail', $this->options->ShowBlock, true);
?>

<link rel="stylesheet" href="https://cdn.staticfile.org/font-awesome/4.7.0/css/font-awesome.css">
<div id="m-container" class="container">
    <div class="row ml-0 mr-0">
        <div class="pl-0 pr-0 col-md-<?php echo $hidden_sidebar? '12' : '8' ?>">
            <div id="article-list">
                <article class="post-article clearfix">
                    <div>
                        <h2 class="title"><a href="<?php $this->permalink() ?>"><?php $this->title() ?></a></h2>
                        <p class="post-big-info">
                            <span class="badge badge-skin"><i class="fa fa-fw fa-user"></i> <a href="<?php $this->author->permalink(); ?>" rel="author"><?php $this->author(); ?></a></span>
                            <span class="badge badge-skin"><i class="fa fa-fw fa-tags"></i> <?php $this->category(','); ?></span>
                            <span class="badge badge-skin"><i class="fa fa-fw fa-calendar"></i> <?php $this->date('Y-m-d'); ?></span>
                            <?php if (class_exists('TeStat_Plugin') && isset($this->options->plugins['activated']['TeStat'])): ?>
                            <span class="badge badge-skin"><i class="fa fa-fw fa-eye"></i> <?php $this->viewsNum(); ?> 次浏览</span>
                            <span class="badge badge-skin"><i class="fa fa-fw fa-thumbs-o-up"></i> <span class="like-num-show"><?php $this->likesNum(); ?></span> 次点赞</span>
                            
                            <?php endif; ?>
                        </p>
                    </div>
                    <div class="article-content clearfix">
                        <?php echo parse_content($this->content,$this->cid,$this->remember('mail',true),$this->user->hasLogin()); ?>
                    </div>
                    <?php if($this->allow('ping')): ?>
                    <div style="padding: 10px 0; margin: 20px auto; width: 100%; font-size:16px; text-align: center;">
                        <button id="rewardButton" disable="enable" onclick="var qr = document.getElementById('QR'); if (qr.style.display === 'none') {qr.style.display='block';} else {qr.style.display='none'}">
                            <span>打赏</span>
                             </button>
                              <div id="QR" style="display: none;">
                               <div id="wechat" style="display: inline-block">
                                 <a class="fancybox" rel="group"><img id="wechat_qr" src="https://www.hait.wang/img/wx.jpg" alt="WeChat Pay"></a>
                                   <p>
                                                <i class="fa fa-weixin">微信打赏</i>
                                              </p>
                                          </div>
                                          <div id="alipay" style="display: inline-block">
                                              <a class="fancybox" rel="group"><img id="alipay_qr" src="https://www.hait.wang/img/zfb.jpg" alt="Alipay"></a>
                                              <p>
                                                  支付宝打赏
                                              </p>
                                          </div>
                                      </div>
                    </div> 
                   
                    <div class="article-copyright">
                            <div class="article-license">
                                <div class="license-item text-muted">
                                  <i class="fa fa-search-plus fa-2"></i>
                                        <span>百度:<?php echo baidu_record() ?>&ensp;&ensp;</span>
                                        <i class="fa fa-google-plus fa-2"></i>
                                        <span>谷歌:<?php echo google_record() ?></span>
                                </div>

                            </div>
                    </div> 
                    
                    <?php endif; ?>
                    <?php if(class_exists('Reward_Plugin') && isset($this->options->plugins['activated']['Reward'])): ?>
                        <?php
                        $extra_str = '';
                        if (class_exists('TeStat_Plugin') && isset($this->options->plugins['activated']['TeStat'])) {
                            $extra_str = '<button class="btn btn-info btn-like" type="button" data-cid="' . $this->cid . '"><i class="fa fa-fw fa-thumbs-o-up"></i> 仅点赞 <span class="like-num-show">' . $this->likesNum . '</span></button>';
                        }
                        ?>
                        <?php Reward_Plugin::show_reward($extra_str); ?>
                        <?php Reward_Plugin::show_modal(); ?>
                    <?php endif; ?>
                    <?php
                        if (class_exists('TeStat_Plugin') && isset($this->options->plugins['activated']['TeStat'])) {
                             _e('<button class="btn btn-info btn-like" type="button" data-cid="' . $this->cid . '"><i class="fa fa-fw fa-thumbs-o-up"></i> 点赞 <span class="like-num-show">' . $this->likesNum . '</span></button>');
                        }
                    ?>
                </article>

            </div>
        <?php if (!empty($this->options->ShowBlock) && in_array('ShowPostBottomBar', $this->options->ShowBlock, true)): ?>
            <div class="block">
                <ul class="post-near">
                    <li>上一篇: <?php $this->thePrev('%s','没有了'); ?></li>
                    <li>下一篇: <?php $this->theNext('%s','没有了'); ?></li>
                </ul>
            </div>
        <?php endif; ?>
            <?php $this->need('comments.php'); ?>

        </div>

    <?php if (!$hidden_sidebar): ?>
        <div class="col-md-4">
            <?php $this->need('sidebar.php'); ?>
        </div>
    <?php endif; ?>
    </div>
</div>
<?php $this->need('footer.php');
