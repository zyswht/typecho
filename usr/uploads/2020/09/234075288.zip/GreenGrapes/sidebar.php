<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit(0); ?><aside id="sidebar">
<link rel="stylesheet" href="https://cdn.staticfile.org/font-awesome/4.7.0/css/font-awesome.css">
    <aside>
        <form method="get" id="searchform" class="form-inline clearfix" action="./">
            <input class="form-control" name="s" id="s" placeholder="搜索关键词..." type="text">
            <button class="btn btn-skin ml-1"><i class="fa fa-search"></i> 查找</button>
        </form>
    </aside>
    <aside>
        <div class="card widget-sets hidden-xs">
            <ul class="nav nav-pills">
                <li class=""><a class="nav-link active" href="#sidebar-new" data-toggle="tab">最新文章</a></li>
                <li class="ml-1"><a class="nav-link" href="#sidebar-comment" data-toggle="tab">最新评论</a></li>
                <li class="ml-1"><a class="nav-link" href="#sidebar-rand" data-toggle="tab">随机文章</a></li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane nav bs-sidenav active in" id="sidebar-new">
                    <ul class="list-group">
                        <?php $this->widget('Widget_Contents_Post_Recent')
                            ->parse('<li class="list-group-item clearfix"><a href="{permalink}">{title}</a></li>'); ?>
                    </ul>
                </div>
                <div class="tab-pane fade" id="sidebar-comment">
                    <?php $this->widget('Widget_Comments_Recent')->to($comments); ?>
                    <ul class="list-group">
                    <?php while($comments->next()): ?>
                        <li class="list-group-item clearfix"><?php $comments->author(false); ?>：<a href="<?php $comments->permalink(); ?>" target="_blank"><?php $comments->excerpt(35, '...'); ?></a></li>
                    <?php endwhile; ?>
                    </ul>
                </div>
                <div class="tab-pane nav bs-sidenav fade" id="sidebar-rand">
                    <?php theme_random_posts();?>
                </div>
            </div>
        </div>
    </aside>
    <?php if(class_exists('Links_Plugin') && isset($this->options->plugins['activated']['Links'])): ?>
    <aside>
        <div class="card card-skin hidden-xs">
            <div class="card-header"><i class="fa fa-link fa-fw"></i> 友情链接</div>
            <ul class="list-group">
                <?php Links_Plugin::output('<li class="list-group-item"><a href="{url}" target="_blank" rel="noopener noreferrer">{name}</a></li>', 10, NULL, true); ?>
            </ul>
        </div>
    </aside>
    <?php endif; ?>
    <?php if(!empty($this->options->ShowBlock) && in_array('ShowCategory', $this->options->ShowBlock)): ?>
    <aside>
        <div class="card card-skin hidden-xs">
            <div class="card-header"><i class="fa fa-book fa-fw"></i> 文章分类</div>
            <div class="list-group category">
                <ul class="widget-list">
                    <?php $this->widget('Widget_Metas_Category_List')->parse('<li><a href="{permalink}">{name} <span class="badge badge-secondary float-right">{count}</span></a></li>'); ?>
                </ul>
            </div>
        </div>
    </aside>
    <?php endif; ?>
    <?php if (!empty($this->options->ShowBlock) && in_array('ShowArchive', $this->options->ShowBlock)): ?>
    <aside>
        <div class="card card-skin hidden-xs">
            <div class="card-header"><i class="fa fa-book fa-fw"></i> <?php _e('归档'); ?></div>
            <div class="list-group category">
                <ul class="widget-list">
                    <?php $this->widget('Widget_Contents_Post_Date', 'type=month&format=Y 年 m 月')->parse('<li><a href="{permalink}">{date}<span class="badge badge-secondary float-right">{count}</span></a></li>'); ?>
                </ul>
            </div>
        </div>
    </aside>
    <?php endif; ?>
    <div id="fixed"></div>
   
    <aside class="fixsidebar">
        <div class="card card-skin hidden-xs">
            <div class="card-header"><i class="fa fa-tags fa-fw"></i> 标签云</div>

<div class="gn_box">     
            <h3><font color=#E80017>2</font><font color=#D1002E>0</font><font color=#BA0045>2</font><font color=#A3005C>1</font><font  color=#8C0073>年</font><font color=#75008A>-</font>
            <font color=#5E00A1>生</font><font color=#4700B8>日</font><font color=#3000CF>倒</font><font color=#1900E6>计</font><font color=#0200FD>时</font></h3><center>
            <div id="CountMsg" class="HotDate"><span id="t_d"> 天</span><span id="t_h"> 时</span><span id="t_m"> 分</span><span id="t_s"> 秒</span></div></center>
            <script type="text/javascript"> 
            function getRTime() {   
                var EndTime = new Date('2021/03/1 10:30:00');  
                var NowTime = new Date();  
                var t = EndTime.getTime() - NowTime.getTime();         
                var d = Math.floor(t / 1000 / 60 / 60 / 24);         
                var h = Math.floor(t / 1000 / 60 / 60 % 24);         
                var m = Math.floor(t / 1000 / 60 % 60);         
                var s = Math.floor(t / 1000 % 60); 
                var day = document.getElementById("t_d");
                if (day != null) {
                    day.innerHTML = d + " 天";   
                }
                var hour = document.getElementById("t_h");
                if (hour != null) {
                    hour.innerHTML = h + " 时";  
                }
                var min = document.getElementById("t_m");
                if (min != null) {
                    min.innerHTML = m + " 分";   
                }
                var sec = document.getElementById("t_s");
                if (sec != null) {
                    sec.innerHTML = s + " 秒";
                }
            }     
            setInterval(getRTime, 1000);     
            </script> 
            </div>      
                




                <div id="meta-cloud">
                     <canvas height="300" id="mycanvas" style="width: 100%">
                     <p>标签云</p>
                     </canvas>   
                </div>


   

        </div>
    </aside>

</aside>